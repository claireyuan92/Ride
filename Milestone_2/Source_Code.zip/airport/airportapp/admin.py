from django.contrib import admin

from .models import *

admin.site.register(RideUser)
admin.site.register(Volunteer)
admin.site.register(NewStudent)
admin.site.register(Flight)
admin.site.register(Car)
admin.site.register(Pickup)