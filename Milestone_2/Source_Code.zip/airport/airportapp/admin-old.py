from django.contrib import admin
from airportapp.models import UserProfile

# Register your models here.
admin.site.register(UserProfile)